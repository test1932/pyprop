from inspect import getmembers, isfunction, getfullargspec
import sys
import re
    

class tester:
    def __init__(self, module, nameStruct = "prop_", iters = 100):
        self.setModule(module)
        self.setPattern(nameStruct)
        self.iters = iters

    @property
    def funcs(self):
        # list of functions in the specified module
        funcs = [f for _, f in getmembers(self.module) if isfunction(f)]
        tests = filter(lambda x: self.namePattern.match(str(x)), funcs)
        genFuncPairs = list(map(lambda x:x(), tests))
        for x in genFuncPairs:
            if len(x[0]) != len(getfullargspec(x[1])[0]):
                raise RuntimeError("invalid number of generators provided")
        return genFuncPairs
    
    def setPattern(self, nameStruct):
        if type(nameStruct) != str:
            raise TypeError("invalid naming pattern")
        self.namePattern = re.compile(f'^<function {nameStruct}', re.I)

    def setModule(self, module):
        try:
            self.module = sys.modules[module]
        except KeyError:
            raise RuntimeError("module not found")
        
    def setIterations(self, iters):
        if type(iters) != int or iters <= 0:
            raise ValueError("invalid number of iters")
        self.iters = iters

    def runTests(self):
        for gens, func in self.funcs:
            tester.runTest(list(map(lambda x: x(), gens)), func, self.iters)
    
    @staticmethod
    def runTest(generators, func, iters):
        fails = []
        for i in range(iters):
            x = [next(g) for g in generators]
            if not func(*x):
                fails.append(x)
        print(f'\nran {iters} tests, with {len(fails)} failures')
        tester.printFails(fails)

    @staticmethod
    def printFails(fails):
        if len(fails):
            print("These include:")
        for i, val in enumerate(fails):
            if i == 5:
                break
            print(f'\t->\t{val}')